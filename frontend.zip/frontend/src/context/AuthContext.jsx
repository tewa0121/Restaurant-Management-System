import React, { createContext, useContext, useState, useCallback, useMemo } from 'react';

// ---------------------------------------------------------------------------
// AuthContext
//
// Exports (all of these are imported somewhere in the app):
//   AuthContext   -> hooks/useAuth.js
//   AuthProvider  -> App.jsx
//   useAuth       -> ProtectedRoute, Login, AppLayout, hooks/useRole.js
//
// Storage keys match what the rest of the app already uses:
//   localStorage 'token' and 'user'        (Login.jsx, ProtectedRoute, services/http.js)
//   localStorage 'registeredUsers'         (SignUp.jsx, Login.jsx demo accounts)
// ---------------------------------------------------------------------------

export const AuthContext = createContext(null);

const readJson = (key, fallback) => {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (e) {
    return fallback;
  }
};

const readToken = () => {
  try {
    return localStorage.getItem('token') || sessionStorage.getItem('token') || null;
  } catch (e) {
    return null;
  }
};

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => readJson('user', null));
  const [token, setToken] = useState(() => readToken());
  const [users, setUsers] = useState(() => readJson('registeredUsers', []));

  // login(user, token)        -> full session (what Login.jsx calls)
  // login({ email, phone })   -> lightweight customer identity (what the cart panel calls)
  const login = useCallback((userOrCredentials, newToken) => {
    if (!userOrCredentials) return null;

    const nextUser = newToken
      ? userOrCredentials
      : {
          id: userOrCredentials.id || `guest-${Date.now()}`,
          name: userOrCredentials.name || userOrCredentials.fullName || userOrCredentials.email || 'Customer',
          email: userOrCredentials.email || '',
          phone: userOrCredentials.phone || '',
          role: userOrCredentials.role || 'customer',
        };

    setUser(nextUser);
    try {
      localStorage.setItem('user', JSON.stringify(nextUser));
    } catch (e) {
      /* storage unavailable: keep the in-memory session only */
    }

    if (newToken) {
      setToken(newToken);
      try {
        localStorage.setItem('token', newToken);
      } catch (e) {
        /* ignore */
      }
    }
    return nextUser;
  }, []);

  // register({ fullName, email, phone }) -> remembers the customer and signs them in
  const register = useCallback(
    (form) => {
      const entry = {
        id: Date.now(),
        fullName: form.fullName || form.name || '',
        email: String(form.email || '').trim().toLowerCase(),
        phone: form.phone || '',
        role: 'customer',
      };
      const next = [...users.filter((u) => u.email !== entry.email), entry];
      setUsers(next);
      try {
        localStorage.setItem('registeredUsers', JSON.stringify(next));
      } catch (e) {
        /* ignore */
      }
      return login({ ...entry, name: entry.fullName });
    },
    [users, login]
  );

  const logout = useCallback(async () => {
    setUser(null);
    setToken(null);
    try {
      localStorage.removeItem('user');
      localStorage.removeItem('token');
      sessionStorage.removeItem('token');
    } catch (e) {
      /* ignore */
    }
  }, []);

  const value = useMemo(
    () => ({
      user,
      token,
      users,
      isAuthenticated: Boolean(user),
      login,
      register,
      logout,
    }),
    [user, token, users, login, register, logout]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};