// src/services/http.js
// Small fetch wrapper with the same shape authService expects: http.get/post/put/patch/delete -> { data }
const BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:5000/api";

export const getToken = () =>
  localStorage.getItem("token") || sessionStorage.getItem("token");

async function request(method, path, body) {
  const token = getToken();
  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    // Expired or invalid session: clear it and send the user to the staff login
    // A wrong password on the login/register form is NOT an expired session, so do not log out for those
    const isAuthForm = path === "/auth/login" || path === "/auth/register";
    if (res.status === 401 && token && !isAuthForm) {
      localStorage.removeItem("token");
      localStorage.removeItem("user");
      sessionStorage.removeItem("token");
      window.location.href = "/admin";
    }
    throw new Error(data.message || `Request failed (${res.status})`);
  }

  return { data };
}

const http = {
  get: (path) => request("GET", path),
  post: (path, body) => request("POST", path, body),
  put: (path, body) => request("PUT", path, body),
  patch: (path, body) => request("PATCH", path, body),
  delete: (path) => request("DELETE", path),
};

export default http;
